var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/[id]/grade/route.js")
R.c("server/chunks/[root-of-the-server]__1jcl7vs._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_[id]_grade_route_actions_1n07bnf.js")
R.m(34891)
module.exports=R.m(34891).exports
