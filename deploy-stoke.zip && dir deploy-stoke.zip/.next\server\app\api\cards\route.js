var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/route.js")
R.c("server/chunks/[root-of-the-server]__0pa00oy._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_route_actions_0w85oxc.js")
R.m(53662)
module.exports=R.m(53662).exports
