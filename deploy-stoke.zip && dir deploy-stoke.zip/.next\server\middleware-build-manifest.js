globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ZpwVhtGPWZifN9T3ebmv9/_buildManifest.js",
    "static/ZpwVhtGPWZifN9T3ebmv9/_ssgManifest.js",
    "static/ZpwVhtGPWZifN9T3ebmv9/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3l04zcqx63h3y.js",
    "static/chunks/0cegfsgm6lvdz.js",
    "static/chunks/1mh6a-0e61pyc.js",
    "static/chunks/turbopack-2kc153v3kmsq5.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
