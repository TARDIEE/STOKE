var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/batch/route.js")
R.c("server/chunks/[root-of-the-server]__0hzpzb5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_batch_route_actions_1i_u24d.js")
R.m(98392)
module.exports=R.m(98392).exports
