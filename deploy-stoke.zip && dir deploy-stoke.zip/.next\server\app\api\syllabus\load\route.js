var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/syllabus/load/route.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0kif62a._.js")
R.c("server/chunks/_next-internal_server_app_api_syllabus_load_route_actions_0lojhgc.js")
R.m(4234)
module.exports=R.m(4234).exports
