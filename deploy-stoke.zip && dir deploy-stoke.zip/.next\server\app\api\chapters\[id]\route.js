var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chapters/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1qck1vk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_chapters_[id]_route_actions_1d8uio1.js")
R.m(9782)
module.exports=R.m(9782).exports
