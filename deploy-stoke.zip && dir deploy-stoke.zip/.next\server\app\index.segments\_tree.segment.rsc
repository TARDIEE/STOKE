:HL["/_next/static/chunks/2-ud5w3p1kvob.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"ZpwVhtGPWZifN9T3ebmv9"}
