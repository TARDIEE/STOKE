var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/flashcards/bulk/route.js")
R.c("server/chunks/[root-of-the-server]__0r4mk6y._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_flashcards_bulk_route_actions_0uak2uu.js")
R.m(22302)
module.exports=R.m(22302).exports
