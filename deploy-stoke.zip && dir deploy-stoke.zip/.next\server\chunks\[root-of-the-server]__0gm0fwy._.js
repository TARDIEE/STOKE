module.exports=[18520,e=>e.a(async(t,s)=>{try{var r=await e.y("@libsql/client-6da938047d5fc1cd");e.n(r),s()}catch(e){s(e)}},!0),22734,(e,t,s)=>{t.exports=e.x("fs",()=>require("fs"))},48663,e=>e.a(async(t,s)=>{try{var r=e.i(18520),E=e.i(14747),T=e.i(22734),a=t([r]);[r]=a.then?(await a)():a;let l=globalThis;function i(){let e;return l.__stokeClient||(l.__stokeClient=(e=process.env.TURSO_DATABASE_URL)?(0,r.createClient)({url:e,authToken:process.env.TURSO_AUTH_TOKEN}):(0,r.createClient)({url:function(){let e=E.default.join(process.cwd(),"data");try{return T.default.existsSync(e)||T.default.mkdirSync(e,{recursive:!0}),T.default.accessSync(e,T.default.constants.W_OK),`file:${E.default.join(e,"stoke.db")}`}catch{return"file:/tmp/stoke.db"}}()})),l.__stokeClient}let c=`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
    pass_salt TEXT NOT NULL, pass_hash TEXT NOT NULL,
    onboarded INTEGER NOT NULL DEFAULT 0, focus_preset TEXT NOT NULL DEFAULT '25/5',
    reminders INTEGER NOT NULL DEFAULT 1, morning TEXT NOT NULL DEFAULT '08:00',
    evening TEXT NOT NULL DEFAULT '19:00', frequency TEXT NOT NULL DEFAULT 'twice',
    theme TEXT NOT NULL DEFAULT 'light', created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS auth_sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS subjects (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '#7C3AED',
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS chapters (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '', ord INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS cards (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL, chapter_id TEXT NOT NULL DEFAULT '',
    front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]',
    notes TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS reviews (
    card_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_reviewed_at INTEGER, next_review_at INTEGER NOT NULL,
    interval_days REAL NOT NULL DEFAULT 0, ease REAL NOT NULL DEFAULT 2.5,
    reps INTEGER NOT NULL DEFAULT 0, lapses INTEGER NOT NULL DEFAULT 0,
    correct INTEGER NOT NULL DEFAULT 0, incorrect INTEGER NOT NULL DEFAULT 0,
    total_reviews INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT 'new'
  );
  CREATE TABLE IF NOT EXISTS review_logs (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    card_id TEXT NOT NULL, at INTEGER NOT NULL, grade TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS study_sessions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT, chapter_id TEXT, start INTEGER NOT NULL, end INTEGER NOT NULL,
    duration_sec INTEGER NOT NULL, kind TEXT NOT NULL DEFAULT 'focus', completed INTEGER NOT NULL DEFAULT 1,
    label TEXT NOT NULL DEFAULT 'learn'
  );
  CREATE TABLE IF NOT EXISTS pomo_settings (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    focus_min INTEGER NOT NULL DEFAULT 25, short_min INTEGER NOT NULL DEFAULT 5,
    long_min INTEGER NOT NULL DEFAULT 15, sessions_before_long INTEGER NOT NULL DEFAULT 4,
    auto_start_breaks INTEGER NOT NULL DEFAULT 0, auto_start_focus INTEGER NOT NULL DEFAULT 0,
    sound INTEGER NOT NULL DEFAULT 1, vibration INTEGER NOT NULL DEFAULT 0, notifications INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'review',
    ref_id TEXT NOT NULL DEFAULT '', ref_subject TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    quadrant TEXT NOT NULL DEFAULT 'q2', status TEXT NOT NULL DEFAULT 'open',
    source TEXT NOT NULL DEFAULT 'auto', count INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS schedule (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'learn',
    chapter_id TEXT NOT NULL DEFAULT '', subject_id TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ai_questions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, chapter_id TEXT NOT NULL DEFAULT '', subject_id TEXT NOT NULL DEFAULT '',
    chapter_name TEXT NOT NULL DEFAULT '',
    front TEXT NOT NULL, back TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id);
  CREATE INDEX IF NOT EXISTS idx_cards_user ON cards(user_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON study_sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_logs_user ON review_logs(user_id);
  CREATE INDEX IF NOT EXISTS idx_tasks_user_day ON tasks(user_id, day);
  CREATE INDEX IF NOT EXISTS idx_schedule_user_day ON schedule(user_id, day);
  CREATE INDEX IF NOT EXISTS idx_aiq_user_day ON ai_questions(user_id, day);
`,R=["ALTER TABLE users ADD COLUMN exam_id TEXT NOT NULL DEFAULT ''","ALTER TABLE users ADD COLUMN exam_name TEXT NOT NULL DEFAULT ''","ALTER TABLE users ADD COLUMN exam_date INTEGER NOT NULL DEFAULT 0","ALTER TABLE users ADD COLUMN focus_goal INTEGER NOT NULL DEFAULT 120","ALTER TABLE users ADD COLUMN ai_key TEXT NOT NULL DEFAULT ''","ALTER TABLE chapters ADD COLUMN weight INTEGER NOT NULL DEFAULT 3","ALTER TABLE chapters ADD COLUMN topics TEXT NOT NULL DEFAULT '[]'","CREATE TABLE IF NOT EXISTS topic_progress (user_id TEXT NOT NULL, key TEXT NOT NULL, learned TEXT NOT NULL DEFAULT '[]', solved TEXT NOT NULL DEFAULT '[]', updated_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (user_id, key))","ALTER TABLE study_sessions ADD COLUMN label TEXT NOT NULL DEFAULT 'learn'","ALTER TABLE ai_questions ADD COLUMN chapter_name TEXT NOT NULL DEFAULT ''"],U=null;async function n(){return U||(U=(async()=>{let e=i();for(let t of c.split(";").map(e=>e.trim()).filter(Boolean))await e.execute(t);for(let t of R)try{await e.execute(t)}catch{}})()),U}async function L(e,...t){return await n(),(await i().execute({sql:e,args:t})).rows}async function o(e,...t){return(await L(e,...t))[0]}async function N(e,...t){await n(),await i().execute({sql:e,args:t})}async function d(e){e.length&&(await n(),await i().batch(e.map(e=>({sql:e.sql,args:e.args}))))}async function u(e){await d([{sql:"DELETE FROM review_logs WHERE user_id = ?",args:[e]},{sql:"DELETE FROM reviews WHERE user_id = ?",args:[e]},{sql:"DELETE FROM cards WHERE user_id = ?",args:[e]},{sql:"DELETE FROM chapters WHERE user_id = ?",args:[e]},{sql:"DELETE FROM subjects WHERE user_id = ?",args:[e]},{sql:"DELETE FROM study_sessions WHERE user_id = ?",args:[e]},{sql:"DELETE FROM tasks WHERE user_id = ?",args:[e]},{sql:"DELETE FROM schedule WHERE user_id = ?",args:[e]},{sql:"DELETE FROM ai_questions WHERE user_id = ?",args:[e]},{sql:"DELETE FROM pomo_settings WHERE user_id = ?",args:[e]},{sql:"INSERT INTO pomo_settings (user_id) VALUES (?)",args:[e]}])}e.s(["batch",0,d,"dbKind",0,function(){return process.env.TURSO_DATABASE_URL?"turso":"file"},"getDb",0,i,"isEphemeral",0,function(){return!process.env.TURSO_DATABASE_URL&&"1"===process.env.VERCEL},"q",0,L,"q1",0,o,"resetUserData",0,u,"run",0,N]),s()}catch(e){s(e)}},!1),70406,(e,t,s)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,s)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},20635,(e,t,s)=>{t.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(e,t,s)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},56704,(e,t,s)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,s)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(e,t,s)=>{t.exports=e.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},93695,(e,t,s)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},81111,(e,t,s)=>{t.exports=e.x("node:stream",()=>require("node:stream"))},14747,(e,t,s)=>{t.exports=e.x("path",()=>require("path"))},58326,e=>e.a(async(t,s)=>{try{var r=e.i(89171),E=e.i(73774),T=t([E]);async function a(){let e=await (0,E.currentUser)();return e?r.NextResponse.json({user:(0,E.publicUser)(e)}):r.NextResponse.json({user:null},{status:401})}async function i(){return await (0,E.destroySession)(),r.NextResponse.json({ok:!0})}[E]=T.then?(await T)():T,e.s(["DELETE",0,i,"GET",0,a]),s()}catch(e){s(e)}},!1),57863,e=>{"use strict";var t=e.i(47909),s=e.i(74017),r=e.i(96250),E=e.i(59756),T=e.i(61916),a=e.i(74677),i=e.i(69741),n=e.i(16795),L=e.i(87718),o=e.i(95169),N=e.i(47587),d=e.i(66012),u=e.i(70101),l=e.i(26937),c=e.i(10372),R=e.i(93695);e.i(52474);var U=e.i(220);let A=new t.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/auth/session/route",pathname:"/api/auth/session",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/auth/session/route.ts",nextConfigOutput:"standalone",userland:()=>e.r(58326),...{}}),{workAsyncStorage:p,workUnitAsyncStorage:O,serverHooks:_}=A;async function D(e,t,r){r.requestMeta&&(0,E.setRequestMeta)(e,r.requestMeta),A.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let p="/api/auth/session/route";p=p.replace(/\/index$/,"")||"/";let O=await A.prepare(e,t,{srcPage:p,multiZoneDraftMode:!1});if(!O)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:_,deploymentId:D,params:h,nextConfig:I,parsedUrl:X,isDraftMode:F,prerenderManifest:C,routerServerContext:x,isOnDemandRevalidate:S,revalidateOnlyGenerated:v,resolvedPathname:g,clientReferenceManifest:f,serverActionsManifest:m}=O,y=(0,i.normalizeAppPath)(p),w=!!(C.dynamicRoutes[y]||C.routes[g]),b=async()=>((null==x?void 0:x.render404)?await x.render404(e,t,X,!1):t.end("This page could not be found"),null);if(w&&!F){let e=!!C.routes[g],t=C.dynamicRoutes[y];if(t&&!1===t.fallback&&!e){if(I.adapterPath)return await b();throw new R.NoFallbackError}}let q=null;!w||A.isDev||F||(q="/index"===(q=g)?"/":q);let M=!0===A.isDev||!w,G=w&&!M;m&&f&&(0,a.setManifestsSingleton)({page:p,clientReferenceManifest:f,serverActionsManifest:m});let k=e.method||"GET",P=(0,T.getTracer)(),j=P.getActiveScopeSpan(),B=!!(null==x?void 0:x.isWrappedByNextServer),H=!!(0,E.getRequestMeta)(e,"minimalMode"),Y=(0,E.getRequestMeta)(e,"incrementalCache")||await A.getIncrementalCache(e,I,C,H);null==Y||Y.resetRequestCache(),globalThis.__incrementalCache=Y;let K={params:h,previewProps:C.preview,renderOpts:{experimental:{authInterrupts:!!I.experimental.authInterrupts,useCacheTimeout:I.experimental.useCacheTimeout},cacheComponents:!!I.cacheComponents,validationLevel:I.experimental.instantInsights.validationLevel,supportsDynamicResponse:M,incrementalCache:Y,hmrRefreshHash:(0,E.getRequestMeta)(e,"hmrRefreshHash"),cacheLifeProfiles:I.cacheLife,staticPageGenerationTimeout:I.staticPageGenerationTimeout,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,s,r,E)=>A.onRequestError(e,t,r,E,x)},sharedContext:{buildId:_,deploymentId:D}},W=new n.NodeNextRequest(e),$=new n.NodeNextResponse(t),V=L.NextRequestAdapter.fromNodeNextRequest(W,(0,L.signalFromNodeResponse)(t)),z=async({previousCacheEntry:s})=>{try{if(!H&&S&&v&&!s)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let E=await A.handle(V,K);e.fetchMetrics=K.renderOpts.fetchMetrics;let T=K.renderOpts.pendingWaitUntil;T&&r.waitUntil&&(r.waitUntil(T),T=void 0);let a=K.renderOpts.collectedTags;if(!w)return await (0,d.sendResponse)(W,$,E,T),null;{let e=await E.blob(),t=(0,u.toNodeOutgoingHttpHeaders)(E.headers);a&&(t[c.NEXT_CACHE_TAGS_HEADER]=a),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let s=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=c.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,r=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=c.INFINITE_CACHE?!1!==s&&s>0?I.expireTime:void 0:K.renderOpts.collectedExpire;return{value:{kind:U.CachedRouteKind.APP_ROUTE,status:E.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:s,expire:r}}}}catch(t){throw(null==s?void 0:s.isStale)&&await A.onRequestError(e,t,{routerKind:"App Router",routePath:p,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:S})},!1,x),t}},Q=async(E,a)=>{try{var i,n;let E=await A.handleResponse({req:e,nextConfig:I,cacheKey:q,routeKind:s.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:v,responseGenerator:z,waitUntil:r.waitUntil,isMinimalMode:H});if(!w)return;if((null==E||null==(i=E.value)?void 0:i.kind)!==U.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==E||null==(n=E.value)?void 0:n.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});H||t.setHeader("x-nextjs-cache",S?"REVALIDATED":E.isMiss?"MISS":E.isStale?"STALE":"HIT"),F&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let T=(0,u.fromNodeOutgoingHttpHeaders)(E.value.headers);H&&w||T.delete(c.NEXT_CACHE_TAGS_HEADER),!E.cacheControl||t.getHeader("Cache-Control")||T.get("Cache-Control")||T.set("Cache-Control",(0,l.getCacheControlHeader)(E.cacheControl)),await (0,d.sendResponse)(W,$,new Response(E.value.body,{headers:T,status:E.value.status||200}));return}catch(t){if(t instanceof R.NoFallbackError||await A.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:S})},!1,x),w)throw t;await (0,d.sendResponse)(W,$,new Response(null,{status:500}));return}finally{(()=>{if(!E)return;let e=t.statusCode;E.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(E.setStatus({code:T.SpanStatusCode.ERROR}),E.setAttribute("error.type",e.toString()));let s=P.getRootSpanAttributes();if(!s)return;if(s.get("next.span_type")!==o.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${s.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=s.get("next.route")||y,i=`${k} ${r}`;E.setAttributes({"next.route":r,"http.route":r,"next.span_name":i}),E.updateName(i),a&&a!==E&&(a.setAttribute("http.route",r),a.updateName(i))})()}};if(B&&j)await Q(j,void 0);else{let t=P.getActiveScopeSpan();await P.withPropagatedContext(e.headers,()=>P.trace(o.BaseServerSpan.handleRequest,{spanName:`${k} ${p}`,kind:T.SpanKind.SERVER,attributes:{"http.method":k,"http.target":e.url}},e=>Q(e,t)),void 0,!B)}}e.s(["handler",0,D,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:O})},"routeModule",0,A,"serverHooks",0,_,"workAsyncStorage",0,p,"workUnitAsyncStorage",0,O])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0gm0fwy._.js.map