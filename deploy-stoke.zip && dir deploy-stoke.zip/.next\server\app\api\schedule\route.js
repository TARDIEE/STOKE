var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/schedule/route.js")
R.c("server/chunks/[root-of-the-server]__0abvvyc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_schedule_route_actions_02qf8b-.js")
R.m(9763)
module.exports=R.m(9763).exports
