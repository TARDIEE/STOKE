module.exports=[18520,e=>e.a(async(t,r)=>{try{var s=await e.y("@libsql/client-6da938047d5fc1cd");e.n(s),r()}catch(e){r(e)}},!0),22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},48663,e=>e.a(async(t,r)=>{try{var s=e.i(18520),a=e.i(14747),T=e.i(22734),E=t([s]);[s]=E.then?(await E)():E;let l=globalThis;function i(){let e;return l.__stokeClient||(l.__stokeClient=(e=process.env.TURSO_DATABASE_URL)?(0,s.createClient)({url:e,authToken:process.env.TURSO_AUTH_TOKEN}):(0,s.createClient)({url:function(){let e=a.default.join(process.cwd(),"data");try{return T.default.existsSync(e)||T.default.mkdirSync(e,{recursive:!0}),T.default.accessSync(e,T.default.constants.W_OK),`file:${a.default.join(e,"stoke.db")}`}catch{return"file:/tmp/stoke.db"}}()})),l.__stokeClient}let c=`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
    pass_salt TEXT NOT NULL, pass_hash TEXT NOT NULL,
    onboarded INTEGER NOT NULL DEFAULT 0, focus_preset TEXT NOT NULL DEFAULT '25/5',
    reminders INTEGER NOT NULL DEFAULT 1, morning TEXT NOT NULL DEFAULT '08:00',
    evening TEXT NOT NULL DEFAULT '19:00', frequency TEXT NOT NULL DEFAULT 'twice',
    theme TEXT NOT NULL DEFAULT 'light', created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS auth_sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS subjects (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '#7C3AED',
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS chapters (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '', ord INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS cards (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL, chapter_id TEXT NOT NULL DEFAULT '',
    front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]',
    notes TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS reviews (
    card_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_reviewed_at INTEGER, next_review_at INTEGER NOT NULL,
    interval_days REAL NOT NULL DEFAULT 0, ease REAL NOT NULL DEFAULT 2.5,
    reps INTEGER NOT NULL DEFAULT 0, lapses INTEGER NOT NULL DEFAULT 0,
    correct INTEGER NOT NULL DEFAULT 0, incorrect INTEGER NOT NULL DEFAULT 0,
    total_reviews INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT 'new'
  );
  CREATE TABLE IF NOT EXISTS review_logs (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    card_id TEXT NOT NULL, at INTEGER NOT NULL, grade TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS study_sessions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT, chapter_id TEXT, start INTEGER NOT NULL, end INTEGER NOT NULL,
    duration_sec INTEGER NOT NULL, kind TEXT NOT NULL DEFAULT 'focus', completed INTEGER NOT NULL DEFAULT 1,
    label TEXT NOT NULL DEFAULT 'learn'
  );
  CREATE TABLE IF NOT EXISTS pomo_settings (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    focus_min INTEGER NOT NULL DEFAULT 25, short_min INTEGER NOT NULL DEFAULT 5,
    long_min INTEGER NOT NULL DEFAULT 15, sessions_before_long INTEGER NOT NULL DEFAULT 4,
    auto_start_breaks INTEGER NOT NULL DEFAULT 0, auto_start_focus INTEGER NOT NULL DEFAULT 0,
    sound INTEGER NOT NULL DEFAULT 1, vibration INTEGER NOT NULL DEFAULT 0, notifications INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'review',
    ref_id TEXT NOT NULL DEFAULT '', ref_subject TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    quadrant TEXT NOT NULL DEFAULT 'q2', status TEXT NOT NULL DEFAULT 'open',
    source TEXT NOT NULL DEFAULT 'auto', count INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS schedule (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'learn',
    chapter_id TEXT NOT NULL DEFAULT '', subject_id TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ai_questions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, chapter_id TEXT NOT NULL DEFAULT '', subject_id TEXT NOT NULL DEFAULT '',
    chapter_name TEXT NOT NULL DEFAULT '',
    front TEXT NOT NULL, back TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id);
  CREATE INDEX IF NOT EXISTS idx_cards_user ON cards(user_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON study_sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_logs_user ON review_logs(user_id);
  CREATE INDEX IF NOT EXISTS idx_tasks_user_day ON tasks(user_id, day);
  CREATE INDEX IF NOT EXISTS idx_schedule_user_day ON schedule(user_id, day);
  CREATE INDEX IF NOT EXISTS idx_aiq_user_day ON ai_questions(user_id, day);
`,R=["ALTER TABLE users ADD COLUMN exam_id TEXT NOT NULL DEFAULT ''","ALTER TABLE users ADD COLUMN exam_name TEXT NOT NULL DEFAULT ''","ALTER TABLE users ADD COLUMN exam_date INTEGER NOT NULL DEFAULT 0","ALTER TABLE users ADD COLUMN focus_goal INTEGER NOT NULL DEFAULT 120","ALTER TABLE users ADD COLUMN ai_key TEXT NOT NULL DEFAULT ''","ALTER TABLE chapters ADD COLUMN weight INTEGER NOT NULL DEFAULT 3","ALTER TABLE chapters ADD COLUMN topics TEXT NOT NULL DEFAULT '[]'","CREATE TABLE IF NOT EXISTS topic_progress (user_id TEXT NOT NULL, key TEXT NOT NULL, learned TEXT NOT NULL DEFAULT '[]', solved TEXT NOT NULL DEFAULT '[]', updated_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (user_id, key))","ALTER TABLE study_sessions ADD COLUMN label TEXT NOT NULL DEFAULT 'learn'","ALTER TABLE ai_questions ADD COLUMN chapter_name TEXT NOT NULL DEFAULT ''"],U=null;async function n(){return U||(U=(async()=>{let e=i();for(let t of c.split(";").map(e=>e.trim()).filter(Boolean))await e.execute(t);for(let t of R)try{await e.execute(t)}catch{}})()),U}async function N(e,...t){return await n(),(await i().execute({sql:e,args:t})).rows}async function o(e,...t){return(await N(e,...t))[0]}async function L(e,...t){await n(),await i().execute({sql:e,args:t})}async function d(e){e.length&&(await n(),await i().batch(e.map(e=>({sql:e.sql,args:e.args}))))}async function u(e){await d([{sql:"DELETE FROM review_logs WHERE user_id = ?",args:[e]},{sql:"DELETE FROM reviews WHERE user_id = ?",args:[e]},{sql:"DELETE FROM cards WHERE user_id = ?",args:[e]},{sql:"DELETE FROM chapters WHERE user_id = ?",args:[e]},{sql:"DELETE FROM subjects WHERE user_id = ?",args:[e]},{sql:"DELETE FROM study_sessions WHERE user_id = ?",args:[e]},{sql:"DELETE FROM tasks WHERE user_id = ?",args:[e]},{sql:"DELETE FROM schedule WHERE user_id = ?",args:[e]},{sql:"DELETE FROM ai_questions WHERE user_id = ?",args:[e]},{sql:"DELETE FROM pomo_settings WHERE user_id = ?",args:[e]},{sql:"INSERT INTO pomo_settings (user_id) VALUES (?)",args:[e]}])}e.s(["batch",0,d,"dbKind",0,function(){return process.env.TURSO_DATABASE_URL?"turso":"file"},"getDb",0,i,"isEphemeral",0,function(){return!process.env.TURSO_DATABASE_URL&&"1"===process.env.VERCEL},"q",0,N,"q1",0,o,"resetUserData",0,u,"run",0,L]),r()}catch(e){r(e)}},!1),70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},20635,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(e,t,r)=>{t.exports=e.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},81111,(e,t,r)=>{t.exports=e.x("node:stream",()=>require("node:stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},60839,e=>e.a(async(t,r)=>{try{var s=e.i(89171),a=e.i(48663),T=e.i(73774),E=t([a,T]);async function i(e){let t=await (0,T.currentUser)();if(!t)return s.NextResponse.json({error:"Not signed in."},{status:401});let r=await e.json().catch(()=>null),E=String(r?.id??""),i=String(r?.subjectId??""),n=String(r?.name??"").trim();if(!E||!i||!n)return s.NextResponse.json({error:"Chapter name is required."},{status:400});let N=(await (0,a.q1)("SELECT COUNT(*) AS n FROM chapters WHERE user_id = ? AND subject_id = ?",t.id,i))?.n??0,o=Math.max(1,Math.min(5,Number(r?.weight??3)));return await (0,a.run)("INSERT INTO chapters (id, user_id, subject_id, name, description, notes, ord, weight, created_at) VALUES (?,?,?,?,?,?,?,?,?)",E,t.id,i,n,String(r?.description??""),String(r?.notes??""),N,o,Date.now()),s.NextResponse.json({ok:!0})}[a,T]=E.then?(await E)():E,e.s(["POST",0,i]),r()}catch(e){r(e)}},!1),53160,e=>{"use strict";var t=e.i(47909),r=e.i(74017),s=e.i(96250),a=e.i(59756),T=e.i(61916),E=e.i(74677),i=e.i(69741),n=e.i(16795),N=e.i(87718),o=e.i(95169),L=e.i(47587),d=e.i(66012),u=e.i(70101),l=e.i(26937),c=e.i(10372),R=e.i(93695);e.i(52474);var U=e.i(220);let A=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/chapters/route",pathname:"/api/chapters",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/chapters/route.ts",nextConfigOutput:"standalone",userland:()=>e.r(60839),...{}}),{workAsyncStorage:p,workUnitAsyncStorage:O,serverHooks:_}=A;async function D(e,t,s){s.requestMeta&&(0,a.setRequestMeta)(e,s.requestMeta),A.isDev&&(0,a.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let p="/api/chapters/route";p=p.replace(/\/index$/,"")||"/";let O=await A.prepare(e,t,{srcPage:p,multiZoneDraftMode:!1});if(!O)return t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve()),null;let{buildId:_,deploymentId:D,params:h,nextConfig:I,parsedUrl:F,isDraftMode:X,prerenderManifest:C,routerServerContext:S,isOnDemandRevalidate:x,revalidateOnlyGenerated:g,resolvedPathname:m,clientReferenceManifest:v,serverActionsManifest:f}=O,w=(0,i.normalizeAppPath)(p),y=!!(C.dynamicRoutes[w]||C.routes[m]),b=async()=>((null==S?void 0:S.render404)?await S.render404(e,t,F,!1):t.end("This page could not be found"),null);if(y&&!X){let e=!!C.routes[m],t=C.dynamicRoutes[w];if(t&&!1===t.fallback&&!e){if(I.adapterPath)return await b();throw new R.NoFallbackError}}let q=null;!y||A.isDev||X||(q="/index"===(q=m)?"/":q);let M=!0===A.isDev||!y,G=y&&!M;f&&v&&(0,E.setManifestsSingleton)({page:p,clientReferenceManifest:v,serverActionsManifest:f});let k=e.method||"GET",P=(0,T.getTracer)(),j=P.getActiveScopeSpan(),B=!!(null==S?void 0:S.isWrappedByNextServer),H=!!(0,a.getRequestMeta)(e,"minimalMode"),Y=(0,a.getRequestMeta)(e,"incrementalCache")||await A.getIncrementalCache(e,I,C,H);null==Y||Y.resetRequestCache(),globalThis.__incrementalCache=Y;let K={params:h,previewProps:C.preview,renderOpts:{experimental:{authInterrupts:!!I.experimental.authInterrupts,useCacheTimeout:I.experimental.useCacheTimeout},cacheComponents:!!I.cacheComponents,validationLevel:I.experimental.instantInsights.validationLevel,supportsDynamicResponse:M,incrementalCache:Y,hmrRefreshHash:(0,a.getRequestMeta)(e,"hmrRefreshHash"),cacheLifeProfiles:I.cacheLife,staticPageGenerationTimeout:I.staticPageGenerationTimeout,waitUntil:s.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,s,a)=>A.onRequestError(e,t,s,a,S)},sharedContext:{buildId:_,deploymentId:D}},W=new n.NodeNextRequest(e),$=new n.NodeNextResponse(t),V=N.NextRequestAdapter.fromNodeNextRequest(W,(0,N.signalFromNodeResponse)(t)),z=async({previousCacheEntry:r})=>{try{if(!H&&x&&g&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await A.handle(V,K);e.fetchMetrics=K.renderOpts.fetchMetrics;let T=K.renderOpts.pendingWaitUntil;T&&s.waitUntil&&(s.waitUntil(T),T=void 0);let E=K.renderOpts.collectedTags;if(!y)return await (0,d.sendResponse)(W,$,a,T),null;{let e=await a.blob(),t=(0,u.toNodeOutgoingHttpHeaders)(a.headers);E&&(t[c.NEXT_CACHE_TAGS_HEADER]=E),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=c.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,s=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=c.INFINITE_CACHE?!1!==r&&r>0?I.expireTime:void 0:K.renderOpts.collectedExpire;return{value:{kind:U.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==r?void 0:r.isStale)&&await A.onRequestError(e,t,{routerKind:"App Router",routePath:p,routeType:"route",revalidateReason:(0,L.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:x})},!1,S),t}},Q=async(a,E)=>{try{var i,n;let a=await A.handleResponse({req:e,nextConfig:I,cacheKey:q,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:x,revalidateOnlyGenerated:g,responseGenerator:z,waitUntil:s.waitUntil,isMinimalMode:H});if(!y)return;if((null==a||null==(i=a.value)?void 0:i.kind)!==U.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==a||null==(n=a.value)?void 0:n.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});H||t.setHeader("x-nextjs-cache",x?"REVALIDATED":a.isMiss?"MISS":a.isStale?"STALE":"HIT"),X&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let T=(0,u.fromNodeOutgoingHttpHeaders)(a.value.headers);H&&y||T.delete(c.NEXT_CACHE_TAGS_HEADER),!a.cacheControl||t.getHeader("Cache-Control")||T.get("Cache-Control")||T.set("Cache-Control",(0,l.getCacheControlHeader)(a.cacheControl)),await (0,d.sendResponse)(W,$,new Response(a.value.body,{headers:T,status:a.value.status||200}));return}catch(t){if(t instanceof R.NoFallbackError||await A.onRequestError(e,t,{routerKind:"App Router",routePath:w,routeType:"route",revalidateReason:(0,L.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:x})},!1,S),y)throw t;await (0,d.sendResponse)(W,$,new Response(null,{status:500}));return}finally{(()=>{if(!a)return;let e=t.statusCode;a.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(a.setStatus({code:T.SpanStatusCode.ERROR}),a.setAttribute("error.type",e.toString()));let r=P.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==o.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route")||w,i=`${k} ${s}`;a.setAttributes({"next.route":s,"http.route":s,"next.span_name":i}),a.updateName(i),E&&E!==a&&(E.setAttribute("http.route",s),E.updateName(i))})()}};if(B&&j)await Q(j,void 0);else{let t=P.getActiveScopeSpan();await P.withPropagatedContext(e.headers,()=>P.trace(o.BaseServerSpan.handleRequest,{spanName:`${k} ${p}`,kind:T.SpanKind.SERVER,attributes:{"http.method":k,"http.target":e.url}},e=>Q(e,t)),void 0,!B)}}e.s(["handler",0,D,"patchFetch",0,function(){return(0,s.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:O})},"routeModule",0,A,"serverHooks",0,_,"workAsyncStorage",0,p,"workUnitAsyncStorage",0,O])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0pnp76g._.js.map