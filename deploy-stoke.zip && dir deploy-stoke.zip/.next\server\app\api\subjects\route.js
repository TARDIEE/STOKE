var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/subjects/route.js")
R.c("server/chunks/[root-of-the-server]__00kqu-2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_subjects_route_actions_15mhdfb.js")
R.m(18082)
module.exports=R.m(18082).exports
