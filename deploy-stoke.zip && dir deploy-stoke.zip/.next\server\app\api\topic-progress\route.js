var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/topic-progress/route.js")
R.c("server/chunks/[root-of-the-server]__0u3ihld._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_topic-progress_route_actions_0lu8mlt.js")
R.m(6792)
module.exports=R.m(6792).exports
