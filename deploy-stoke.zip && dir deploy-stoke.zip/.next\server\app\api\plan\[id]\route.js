var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/plan/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0zgw0u8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_plan_[id]_route_actions_1ukaz5_.js")
R.m(12773)
module.exports=R.m(12773).exports
