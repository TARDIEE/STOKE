var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__1gw_p1q._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_1bpm9ac.js")
R.m(83579)
module.exports=R.m(83579).exports
