var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/schedule/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1wglzwd._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_schedule_[id]_route_actions_1nl7o2j.js")
R.m(8172)
module.exports=R.m(8172).exports
