var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/schedule/reschedule/route.js")
R.c("server/chunks/[root-of-the-server]__1do4is4._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_schedule_reschedule_route_actions_0p2uq1z.js")
R.m(38217)
module.exports=R.m(38217).exports
