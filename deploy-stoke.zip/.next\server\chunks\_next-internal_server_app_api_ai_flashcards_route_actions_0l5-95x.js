module.exports=[83881,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_flashcards_route_actions_0l5-95x.js.map