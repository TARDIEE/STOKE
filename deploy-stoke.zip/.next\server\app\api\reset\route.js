var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reset/route.js")
R.c("server/chunks/[root-of-the-server]__0emzq8a._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_reset_route_actions_1tcp2ms.js")
R.m(77517)
module.exports=R.m(77517).exports
