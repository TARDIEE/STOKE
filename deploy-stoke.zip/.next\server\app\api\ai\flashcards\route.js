var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/flashcards/route.js")
R.c("server/chunks/[root-of-the-server]__1pre0cy._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_flashcards_route_actions_0l5-95x.js")
R.m(76044)
module.exports=R.m(76044).exports
