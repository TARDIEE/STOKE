module.exports=[18520,e=>e.a(async(T,E)=>{try{var t=await e.y("@libsql/client-6da938047d5fc1cd");e.n(t),E()}catch(e){E(e)}},!0),22734,(e,T,E)=>{T.exports=e.x("fs",()=>require("fs"))},46786,(e,T,E)=>{T.exports=e.x("os",()=>require("os"))},48663,e=>e.a(async(T,E)=>{try{var t=e.i(18520),s=e.i(14747),r=e.i(22734),a=e.i(46786),L=T([t]);[t]=L.then?(await L)():L;let U=!1,O=globalThis;function N(){let e;return O.__stokeClient||(O.__stokeClient=(e=process.env.TURSO_DATABASE_URL)?(0,t.createClient)({url:e,authToken:process.env.TURSO_AUTH_TOKEN}):(0,t.createClient)({url:function(){for(let e of[s.default.join(process.cwd(),"data","stoke.db"),s.default.join(a.default.tmpdir(),"stoke.db")])try{return r.default.mkdirSync(s.default.dirname(e),{recursive:!0}),r.default.accessSync(s.default.dirname(e),r.default.constants.W_OK),r.default.closeSync(r.default.openSync(e,"a")),`file:${e}`}catch{continue}return U=!0,"file::memory:?cache=shared"}()})),O.__stokeClient}let A=`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
    pass_salt TEXT NOT NULL, pass_hash TEXT NOT NULL,
    onboarded INTEGER NOT NULL DEFAULT 0, focus_preset TEXT NOT NULL DEFAULT '25/5',
    reminders INTEGER NOT NULL DEFAULT 1, morning TEXT NOT NULL DEFAULT '08:00',
    evening TEXT NOT NULL DEFAULT '19:00', frequency TEXT NOT NULL DEFAULT 'twice',
    theme TEXT NOT NULL DEFAULT 'light', created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS auth_sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS subjects (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '#7C3AED',
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS chapters (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '', ord INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS cards (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL, chapter_id TEXT NOT NULL DEFAULT '',
    front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]',
    notes TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS reviews (
    card_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_reviewed_at INTEGER, next_review_at INTEGER NOT NULL,
    interval_days REAL NOT NULL DEFAULT 0, ease REAL NOT NULL DEFAULT 2.5,
    reps INTEGER NOT NULL DEFAULT 0, lapses INTEGER NOT NULL DEFAULT 0,
    correct INTEGER NOT NULL DEFAULT 0, incorrect INTEGER NOT NULL DEFAULT 0,
    total_reviews INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT 'new'
  );
  CREATE TABLE IF NOT EXISTS review_logs (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    card_id TEXT NOT NULL, at INTEGER NOT NULL, grade TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS study_sessions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id TEXT, chapter_id TEXT, start INTEGER NOT NULL, end INTEGER NOT NULL,
    duration_sec INTEGER NOT NULL, kind TEXT NOT NULL DEFAULT 'focus', completed INTEGER NOT NULL DEFAULT 1,
    label TEXT NOT NULL DEFAULT 'learn'
  );
  CREATE TABLE IF NOT EXISTS pomo_settings (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    focus_min INTEGER NOT NULL DEFAULT 25, short_min INTEGER NOT NULL DEFAULT 5,
    long_min INTEGER NOT NULL DEFAULT 15, sessions_before_long INTEGER NOT NULL DEFAULT 4,
    auto_start_breaks INTEGER NOT NULL DEFAULT 0, auto_start_focus INTEGER NOT NULL DEFAULT 0,
    sound INTEGER NOT NULL DEFAULT 1, vibration INTEGER NOT NULL DEFAULT 0, notifications INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'review',
    ref_id TEXT NOT NULL DEFAULT '', ref_subject TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    quadrant TEXT NOT NULL DEFAULT 'q2', status TEXT NOT NULL DEFAULT 'open',
    source TEXT NOT NULL DEFAULT 'auto', count INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS schedule (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'learn',
    chapter_id TEXT NOT NULL DEFAULT '', subject_id TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ai_questions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL, chapter_id TEXT NOT NULL DEFAULT '', subject_id TEXT NOT NULL DEFAULT '',
    chapter_name TEXT NOT NULL DEFAULT '',
    front TEXT NOT NULL, back TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id);
  CREATE INDEX IF NOT EXISTS idx_cards_user ON cards(user_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON study_sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_logs_user ON review_logs(user_id);
  CREATE INDEX IF NOT EXISTS idx_tasks_user_day ON tasks(user_id, day);
  CREATE INDEX IF NOT EXISTS idx_schedule_user_day ON schedule(user_id, day);
  CREATE INDEX IF NOT EXISTS idx_aiq_user_day ON ai_questions(user_id, day);
`,l=["ALTER TABLE users ADD COLUMN exam_id TEXT NOT NULL DEFAULT ''","ALTER TABLE users ADD COLUMN exam_name TEXT NOT NULL DEFAULT ''","ALTER TABLE users ADD COLUMN exam_date INTEGER NOT NULL DEFAULT 0","ALTER TABLE users ADD COLUMN focus_goal INTEGER NOT NULL DEFAULT 120","ALTER TABLE users ADD COLUMN ai_key TEXT NOT NULL DEFAULT ''","ALTER TABLE chapters ADD COLUMN weight INTEGER NOT NULL DEFAULT 3","ALTER TABLE chapters ADD COLUMN topics TEXT NOT NULL DEFAULT '[]'","CREATE TABLE IF NOT EXISTS topic_progress (user_id TEXT NOT NULL, key TEXT NOT NULL, learned TEXT NOT NULL DEFAULT '[]', solved TEXT NOT NULL DEFAULT '[]', updated_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (user_id, key))","ALTER TABLE study_sessions ADD COLUMN label TEXT NOT NULL DEFAULT 'learn'","ALTER TABLE ai_questions ADD COLUMN chapter_name TEXT NOT NULL DEFAULT ''"],R=null;async function i(){return R||(R=(async()=>{let e=N();for(let T of A.split(";").map(e=>e.trim()).filter(Boolean))await e.execute(T);for(let T of l)try{await e.execute(T)}catch{}})()),R}async function n(e,...T){return await i(),(await N().execute({sql:e,args:T})).rows}async function o(e,...T){return(await n(e,...T))[0]}async function d(e,...T){await i(),await N().execute({sql:e,args:T})}async function c(e){e.length&&(await i(),await N().batch(e.map(e=>({sql:e.sql,args:e.args}))))}async function u(e){await c([{sql:"DELETE FROM review_logs WHERE user_id = ?",args:[e]},{sql:"DELETE FROM reviews WHERE user_id = ?",args:[e]},{sql:"DELETE FROM cards WHERE user_id = ?",args:[e]},{sql:"DELETE FROM chapters WHERE user_id = ?",args:[e]},{sql:"DELETE FROM subjects WHERE user_id = ?",args:[e]},{sql:"DELETE FROM study_sessions WHERE user_id = ?",args:[e]},{sql:"DELETE FROM tasks WHERE user_id = ?",args:[e]},{sql:"DELETE FROM schedule WHERE user_id = ?",args:[e]},{sql:"DELETE FROM ai_questions WHERE user_id = ?",args:[e]},{sql:"DELETE FROM pomo_settings WHERE user_id = ?",args:[e]},{sql:"INSERT INTO pomo_settings (user_id) VALUES (?)",args:[e]}])}e.s(["batch",0,c,"dbKind",0,function(){return process.env.TURSO_DATABASE_URL?"turso":"file"},"getDb",0,N,"isEphemeral",0,function(){return!process.env.TURSO_DATABASE_URL&&"1"===process.env.VERCEL||U},"q",0,n,"q1",0,o,"resetUserData",0,u,"run",0,d,"storageKind",0,function(){return process.env.TURSO_DATABASE_URL?"turso":U?"memory":"file"}]),E()}catch(e){E(e)}},!1),70406,(e,T,E)=>{T.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,T,E)=>{T.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},20635,(e,T,E)=>{T.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(e,T,E)=>{T.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},56704,(e,T,E)=>{T.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,T,E)=>{T.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(e,T,E)=>{T.exports=e.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},93695,(e,T,E)=>{T.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},81111,(e,T,E)=>{T.exports=e.x("node:stream",()=>require("node:stream"))},14747,(e,T,E)=>{T.exports=e.x("path",()=>require("path"))},69072,e=>{"use strict";let T=process.env.GROQ_MODEL||"openai/gpt-oss-120b";function E(e){return String(e??"").trim()}function t(e){try{let T=JSON.parse(e),t=Array.isArray(T)?T:T.cards??T.flashcards??T.questions??[];if(Array.isArray(t))return t.map(e=>({front:E(e?.front??e?.q??e?.question),back:E(e?.back??e?.a??e?.answer)})).filter(e=>e.front&&e.back)}catch{}let T=e.match(/\[[\s\S]*\]/);if(T)try{let e=JSON.parse(T[0]);if(Array.isArray(e))return e.map(e=>({front:E(e?.front??e?.q??e?.question),back:E(e?.back??e?.a??e?.answer)})).filter(e=>e.front&&e.back)}catch{}return[]}async function s(e,T){let E=(await T.execute({sql:"SELECT ai_key FROM users WHERE id = ?",args:[e]})).rows[0];return(E?.ai_key||process.env.GROQ_API_KEY||"").trim()}async function r(e,E,s,r,a){let L=a?.trim()?` Base the cards ONLY on the following study notes — do not add facts outside them: """${a.trim().slice(0,2e3)}"""`:"",N=await fetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${s}`},body:JSON.stringify({model:T,temperature:.7,max_tokens:2200,response_format:{type:"json_object"},messages:[{role:"system",content:'You create study flashcards. Reply with ONLY a JSON object shaped {"cards": [{"front": "question", "back": "concise answer"}]}. No markdown, no extra text.'},{role:"user",content:`Create ${E} flashcards for studying "${e}"${r?` (chapter: ${r})`:""}. Mix definitions, key formulas/facts, and one application question. Keep fronts under 140 characters and backs under 300 characters.${L}`}]})});if(!N.ok){let e=await N.text().catch(()=>"");throw Error(`AI service error (${N.status}). ${e.slice(0,120)}`)}let i=await N.json();return t(i?.choices?.[0]?.message?.content??"")}async function a(e,T,E,s){let r=s?.trim()?` Base the cards ONLY on the following study notes — do not add facts outside them: """${s.trim().slice(0,2e3)}"""`:"",a=`Create ${T} flashcards for studying "${e}"${E?` (chapter: ${E})`:""}. Mix definitions, key formulas/facts, and one application question. Keep fronts under 140 characters and backs under 300 characters.${r} Do not ask clarifying questions. Output ONLY a JSON object shaped {"cards": [{"front": "question", "back": "concise answer"}]}. No markdown, no extra text.`,L=null;for(let e=0;e<2;e++)try{let e=await fetch(`https://text.pollinations.ai/${encodeURIComponent(a)}`,{signal:AbortSignal.timeout(6e4),headers:{Accept:"text/plain"}});if(!e.ok)throw Error(`Open AI service error (${e.status}).`);let E=await e.text(),s=t(E).slice(0,T);if(s.length)return s;L=Error("Open AI returned nothing usable.")}catch(e){L=e}throw L instanceof Error?L:Error("Open AI failed.")}e.s(["aiModelName",0,function(){return T},"generateCards",0,r,"generateCardsOpen",0,a,"getAiKey",0,s])},26979,e=>{"use strict";e.s(["uid",0,function(){return Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-4)}])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1q8l4dy._.js.map