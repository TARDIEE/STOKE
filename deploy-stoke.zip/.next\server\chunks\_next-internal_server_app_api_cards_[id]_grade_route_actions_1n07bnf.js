module.exports=[76834,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cards_%5Bid%5D_grade_route_actions_1n07bnf.js.map