module.exports=[44076,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_topic-progress_route_actions_0lu8mlt.js.map