var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0pc3g5n._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_[id]_route_actions_1e-vkww.js")
R.m(71922)
module.exports=R.m(71922).exports
