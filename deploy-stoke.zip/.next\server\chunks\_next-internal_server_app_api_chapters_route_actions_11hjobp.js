module.exports=[79126,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chapters_route_actions_11hjobp.js.map