var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/exams/route.js")
R.c("server/chunks/[root-of-the-server]__02yklmh._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_exams_route_actions_1c_zhtj.js")
R.m(74276)
module.exports=R.m(74276).exports
