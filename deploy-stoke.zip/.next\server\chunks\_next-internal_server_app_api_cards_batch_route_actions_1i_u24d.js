module.exports=[44175,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cards_batch_route_actions_1i_u24d.js.map