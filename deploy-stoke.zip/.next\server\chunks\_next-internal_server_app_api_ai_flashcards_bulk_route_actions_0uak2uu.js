module.exports=[8547,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_flashcards_bulk_route_actions_0uak2uu.js.map