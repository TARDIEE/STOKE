module.exports=[5189,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_schedule_move_route_actions_18-bdof.js.map