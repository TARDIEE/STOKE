var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chapters/route.js")
R.c("server/chunks/[root-of-the-server]__043l3m3._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_chapters_route_actions_11hjobp.js")
R.m(53160)
module.exports=R.m(53160).exports
