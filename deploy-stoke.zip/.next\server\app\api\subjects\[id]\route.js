var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/subjects/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0ebg715._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_subjects_[id]_route_actions_1a0yp_s.js")
R.m(27928)
module.exports=R.m(27928).exports
