module.exports=[20480,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_questions_route_actions_0ne82jw.js.map