var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/route.js")
R.c("server/chunks/[root-of-the-server]__1n57p84._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_sessions_route_actions_1lwcye0.js")
R.m(95764)
module.exports=R.m(95764).exports
