module.exports=[85610,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_exams_route_actions_1c_zhtj.js.map