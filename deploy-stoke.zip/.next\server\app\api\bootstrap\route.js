var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bootstrap/route.js")
R.c("server/chunks/[root-of-the-server]__1s5ni-8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_bootstrap_route_actions_04u88ip.js")
R.m(88426)
module.exports=R.m(88426).exports
