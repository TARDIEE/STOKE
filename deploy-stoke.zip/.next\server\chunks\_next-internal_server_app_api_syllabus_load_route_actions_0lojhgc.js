module.exports=[74,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_syllabus_load_route_actions_0lojhgc.js.map