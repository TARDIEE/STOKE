var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/plan/regenerate/route.js")
R.c("server/chunks/_16xo4gl._.js")
R.c("server/chunks/[root-of-the-server]__058spir._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_plan_regenerate_route_actions_0ndgyt5.js")
R.m(75060)
module.exports=R.m(75060).exports
