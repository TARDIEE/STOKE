var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/schedule/move/route.js")
R.c("server/chunks/[root-of-the-server]__1yfplif._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_schedule_move_route_actions_18-bdof.js")
R.m(37939)
module.exports=R.m(37939).exports
