var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/questions/route.js")
R.c("server/chunks/[root-of-the-server]__1q8l4dy._.js")
R.c("server/chunks/_20uo9ns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1e0iamk._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_questions_route_actions_0ne82jw.js")
R.m(63072)
module.exports=R.m(63072).exports
